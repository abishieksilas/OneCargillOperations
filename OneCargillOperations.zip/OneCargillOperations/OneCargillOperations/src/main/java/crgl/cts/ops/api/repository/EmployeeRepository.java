package crgl.cts.ops.api.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import crgl.cts.ops.api.entities.Employee;
import crgl.cts.ops.api.entities.EmployeeProject;
import crgl.cts.ops.api.entities.EsaProject;

@Repository
public class EmployeeRepository {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeRepository.class);
	@Autowired
	JdbcTemplate jdbcTemplate;

	// returns list of employees
	public List<Employee> getEmployees() {
		List<Employee> dbemployees = new ArrayList<Employee>();
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet("select * from EMPLOYEES");
		while (rowSet.next()) {
			Employee employee = new Employee();
			employee.setEmployeeId(rowSet.getInt("EMPLOYEE_ID"));
			employee.setCtsName(rowSet.getString("CTS_NAME").replaceAll(",", " "));
			employee.setDsid(rowSet.getString("DSID"));
			employee.setCargillName(rowSet.getString("CARGILL_NAME"));
			employee.setCargillEmailId(rowSet.getString("CARGILL_EMAIL_ID"));
			employee.setActive(rowSet.getBoolean("IS_ONSITE"));
			employee.setCargillDOJ(rowSet.getDate("CARGILL_DOJ"));
			employee.setOnsite(rowSet.getBoolean("IS_ACTIVE"));
			dbemployees.add(employee);
		}
		
		return dbemployees;

	}

	// returns list of esaprojects
	public List<EsaProject> getProjects() {
		List<EsaProject> dbesaprojects = new ArrayList<EsaProject>();
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet("select * from ESA_PROJECTS");
		while (rowSet.next()) {
			EsaProject esa = new EsaProject();
			esa.setEsaProjectId(rowSet.getInt("ESA_PROJECT_ID"));
			esa.setEsaCustomerId(rowSet.getInt("ESA_CUSTOMER_ID"));
			esa.setEsaCustomerName(rowSet.getString("ESA_CUSTOMER_NAME"));
			esa.setInvoicingCountry(rowSet.getString("INVOICING_COUNTRY"));
			esa.setEsaProjectName(rowSet.getString("ESA_PROJECT_NAME"));
			esa.setProjectManagerId(rowSet.getInt("PROJECT_MANAGER_ID"));
			esa.setProjectManagerName(rowSet.getString("PROJECT_MANAGER_NAME"));
			esa.setLeadership(rowSet.getString("LEADERSHIP"));
			dbesaprojects.add(esa);
		}
		return dbesaprojects;

	}

	// returns list of employee projects
	public List<EmployeeProject> getEmployeeProjects() {
		List<EmployeeProject> dbemployeeprojects = new ArrayList<EmployeeProject>();
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet("select * from EMPLOYEE_PROJECTS");
		while (rowSet.next()) {
			EmployeeProject ep = new EmployeeProject();
			ep.setEmpProjId(rowSet.getInt("EMP_PROJ_ID"));
			ep.setEmployeeId(rowSet.getInt("EMPLOYEE_ID"));
			ep.setEsaProjectId(rowSet.getInt("ESA_PROJECT_ID"));
			ep.setAssignmentStartDate(rowSet.getDate("ASSIGNMENT_START_DATE"));
			ep.setAssignmentEndDate(rowSet.getDate("ASSIGNMENT_END_DATE"));
			ep.setAllocationPercentage(rowSet.getInt("ALLOCATION_PERCENTAGE"));
			ep.setProjectBillability(rowSet.getString("PROJECT_BILLABILITY"));
			ep.setProjectType(rowSet.getString("PROJECT_TYPE"));
			ep.setWorkOrderNumber(rowSet.getString("WORK_ORDER_NUMBER"));
			ep.setSowRole(rowSet.getString("SOW_ROLE"));
			ep.setRateLocal(rowSet.getBigDecimal("RATE_LOCAL"));
			ep.setRateUsd(rowSet.getBigDecimal("RATE_USD"));
			ep.setWorkPackage(rowSet.getString("WORK_PACKAGE"));
			dbemployeeprojects.add(ep);
		}
		return dbemployeeprojects;
	}

	public void upload(List<Employee> excelemployeesList, List<EsaProject> excelesaProjectsList,
			List<EmployeeProject> excelemployeeProjectsList) {
		LOGGER.info("Entry : upload()");
		//Get the employee, project and employee project details from DB
		List<Employee> employees = getEmployees();
		List<EsaProject> esaProjects = getProjects();
		List<EmployeeProject> employeeProjects = getEmployeeProjects();
		/**
		 * Identify whether project details is new or updated
		 * 1. If new, insert into DB
		 * 2. If existing project, check whether any details are updated. 
		 * 		a. If existing project details are changed, update it in DB
		 */
		//Identify existing(updated projects) and new projects and insert/update it in DB
		processEsaProjects(excelesaProjectsList, esaProjects);
		//Identify existing(updated employees) and new employees and insert/update it in DB
		processEmployees(excelemployeesList, employees);
		//Identify existing(updated employees projects) and new employee projects and insert/update it in DB
		processEmployeeProjetcs(excelemployeeProjectsList, employeeProjects);
		LOGGER.info("Exit : upload()");
	}
	/**
	 * To identify existing(updated employee projects) and new employee projects and insert/update it in DB
	 * @param excelemployeeProjectsList
	 * @param employeeProjects
	 */
	private void processEmployeeProjetcs(List<EmployeeProject> excelemployeeProjectsList,
			List<EmployeeProject> employeeProjects) {
		List<EmployeeProject> employeeProjectsUpd = new ArrayList<>();
		List<EmployeeProject> employeeProjectsIns = new ArrayList<>();
		excelemployeeProjectsList.forEach((EmployeeProject employeeProject) -> {
			boolean isNewProject = true;
			for (EmployeeProject dbEmployeeProject : employeeProjects) 
			{
				if (dbEmployeeProject.getEsaProjectId() == employeeProject.getEsaProjectId()
						&& dbEmployeeProject.getEmployeeId() == employeeProject.getEmployeeId()) 
				{
					if(!dbEmployeeProject.equals(employeeProject))
					{
						employeeProjectsUpd.add(employeeProject);
					}  
					isNewProject = false;
					break;
				}
			}
			if(isNewProject)
			{
				employeeProjectsIns.add(employeeProject);
			}
		}); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		//Batch Update for Employee Projects
		if(!employeeProjectsUpd.isEmpty())
		{
			this.jdbcTemplate.batchUpdate(
					"UPDATE EMPLOYEE_PROJECTS SET ASSIGNMENT_START_DATE= ? ,ASSIGNMENT_END_DATE= ? ,ALLOCATION_PERCENTAGE= ? ,"
							+ "PROJECT_BILLABILITY= ? ,PROJECT_TYPE= ? ,WORK_ORDER_NUMBER= ? ,SOW_ROLE= ? ,RATE_LOCAL= ? ,RATE_USD= ? ,"
							+ "WORK_PACKAGE= ?  where EMPLOYEE_ID = ? AND ESA_PROJECT_ID=?",
	                new BatchPreparedStatementSetter() 
					{
	                    public void setValues(PreparedStatement ps, int i)
							throws SQLException {
	                    	if(null != employeeProjectsUpd.get(i).getAssignmentStartDate())
	                    	{
	                    		ps.setDate(1, java.sql.Date.valueOf(dateFormat.format(employeeProjectsUpd.get(i).getAssignmentStartDate())));
	                    	}
	                        if(null != employeeProjectsUpd.get(i).getAssignmentEndDate())
	                        {
	                        	ps.setDate(2, java.sql.Date.valueOf(dateFormat.format(employeeProjectsUpd.get(i).getAssignmentEndDate())));
	                        }
	                        
	                        ps.setInt(3, employeeProjectsUpd.get(i).getAllocationPercentage());
	                        ps.setString(4, employeeProjectsUpd.get(i).getProjectBillability());
	                        ps.setString(5, employeeProjectsUpd.get(i).getProjectType());
	                        ps.setString(6, employeeProjectsUpd.get(i).getWorkOrderNumber());
	                        ps.setString(7, employeeProjectsUpd.get(i).getSowRole());
	                        ps.setBigDecimal(8, employeeProjectsUpd.get(i).getRateLocal());
	                        ps.setBigDecimal(9, employeeProjectsUpd.get(i).getRateUsd());
	                        ps.setString(10, employeeProjectsUpd.get(i).getWorkPackage());
	                        ps.setInt(11, employeeProjectsUpd.get(i).getEmployeeId());
	                        ps.setInt(12, employeeProjectsUpd.get(i).getEsaProjectId());
	                    }
	                    public int getBatchSize() {
	                        return employeeProjectsUpd.size();
	                    }

	                });
		}
		//Batch Insert for Employee Projects
		if(!employeeProjectsIns.isEmpty())
		{
			this.jdbcTemplate.batchUpdate(
					"insert into EMPLOYEE_PROJECTS(EMPLOYEE_ID,ESA_PROJECT_ID,ASSIGNMENT_START_DATE,ASSIGNMENT_END_DATE,"
					+ "ALLOCATION_PERCENTAGE,PROJECT_BILLABILITY,PROJECT_TYPE,WORK_ORDER_NUMBER,SOW_ROLE,RATE_LOCAL,"
					+ "RATE_USD,WORK_PACKAGE) values (?,?,?,?,?,?,?,?,?,?,?,?)",
	                new BatchPreparedStatementSetter() 
					{
	                    public void setValues(PreparedStatement ps, int i)
							throws SQLException {
	                        ps.setInt(1, employeeProjectsIns.get(i).getEmployeeId());
	                        ps.setInt(2, employeeProjectsIns.get(i).getEsaProjectId());
	                        if(null != employeeProjectsIns.get(i).getAssignmentStartDate())
	                        {
	                        	ps.setDate(3, java.sql.Date.valueOf(dateFormat.format(employeeProjectsIns.get(i).getAssignmentStartDate())));
	                        }
	                        if(null != employeeProjectsIns.get(i).getAssignmentEndDate())
	                        {
	                        	ps.setDate(4, java.sql.Date.valueOf(dateFormat.format(employeeProjectsIns.get(i).getAssignmentEndDate())));
	                        }
	                        ps.setInt(5, employeeProjectsIns.get(i).getAllocationPercentage());
	                        ps.setString(6, employeeProjectsIns.get(i).getProjectBillability());
	                        ps.setString(7, employeeProjectsIns.get(i).getProjectType());
	                        ps.setString(8, employeeProjectsIns.get(i).getWorkOrderNumber());
	                        ps.setString(9, employeeProjectsIns.get(i).getSowRole());
	                        ps.setBigDecimal(10, employeeProjectsIns.get(i).getRateLocal());
	                        ps.setBigDecimal(11, employeeProjectsIns.get(i).getRateUsd());
	                        ps.setString(12, employeeProjectsIns.get(i).getWorkPackage());
	                    }
	                    public int getBatchSize() {
	                        return employeeProjectsIns.size();
	                    }
	                });
		}
	}
	/**
	 * To identify existing(updated employees) and new employees and insert/update it in DB
	 * @param excelemployeesList
	 * @param employees
	 */
	private void processEmployees(List<Employee> excelemployeesList, List<Employee> employees) {
		Map<Integer, Employee> employeesUpdMap = new HashMap<>();
		Map<Integer, Employee> employeesInsMap = new HashMap<>();
		excelemployeesList.forEach((Employee employee) -> {
			boolean isNewEmp = true;
			for (Employee dbemployee : employees) 
			{
				if (dbemployee.getEmployeeId() == employee.getEmployeeId()) 
				{
					if(!dbemployee.equals(employee))
					{
						employeesUpdMap.put(employee.getEmployeeId(), employee);
					}
					isNewEmp = false;
					break;
				}
			}
			if(isNewEmp)
			{
				employeesInsMap.put(employee.getEmployeeId(), employee);
			}
		});
		List<Employee> employeesUpd = new ArrayList<>();
		employeesUpd.addAll(employeesUpdMap.values());
		List<Employee> employeesIns = new ArrayList<>();
		employeesIns.addAll(employeesInsMap.values());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		//Batch Update for Employees
		if(!employeesUpd.isEmpty())
		{
			this.jdbcTemplate.batchUpdate(
					"UPDATE EMPLOYEES SET DSID= ? ,CARGILL_NAME= ? ,CARGILL_EMAIL_ID= ? ,IS_ONSITE= ? ,CARGILL_DOJ= ? ,IS_ACTIVE= ? where EMPLOYEE_ID= ?",
	                new BatchPreparedStatementSetter() 
					{
	                    public void setValues(PreparedStatement ps, int i)
							throws SQLException {
	                        ps.setString(1, employeesUpd.get(i).getDsid());
	                        ps.setString(2, employeesUpd.get(i).getCargillName());
	                        ps.setString(3, employeesUpd.get(i).getCargillEmailId());
	                        ps.setBoolean(4, employeesUpd.get(i).isOnsite());
	                        if(null != employeesUpd.get(i).getCargillDOJ())
	                        {
	                        	ps.setDate(5, java.sql.Date.valueOf(dateFormat.format(employeesUpd.get(i).getCargillDOJ())));
	                        }
	                        ps.setBoolean(6, employeesUpd.get(i).isOnsite());
	                        ps.setInt(7, employeesUpd.get(i).getEmployeeId());
	                    }
	                    public int getBatchSize() {
	                        return employeesUpd.size();
	                    }

	                });
		}
		//Batch Insert for Employees
		if(!employeesIns.isEmpty())
		{
			this.jdbcTemplate.batchUpdate(
					"insert into EMPLOYEES(EMPLOYEE_ID,CTS_NAME,DSID,CARGILL_NAME,CARGILL_EMAIL_ID,"
					+ "IS_ONSITE,CARGILL_DOJ,IS_ACTIVE) values (?,?,?,?,?,?,?,?)"
							,
	                new BatchPreparedStatementSetter() 
					{
	                    public void setValues(PreparedStatement ps, int i)
							throws SQLException {
	                        ps.setInt(1, employeesIns.get(i).getEmployeeId());
	                        ps.setString(2, employeesIns.get(i).getCtsName());
	                        ps.setString(3, employeesIns.get(i).getDsid());
	                        ps.setString(4, employeesIns.get(i).getCargillName());
	                        ps.setString(5, employeesIns.get(i).getCargillEmailId());
	                        ps.setBoolean(6, employeesIns.get(i).isOnsite());
	                        if(null != employeesIns.get(i).getCargillDOJ())
	                        {
	                        	 ps.setDate(7, java.sql.Date.valueOf(dateFormat.format(employeesIns.get(i).getCargillDOJ())));
	                        }
	                        ps.setBoolean(8, employeesIns.get(i).isActive());
	                    }
	                    public int getBatchSize() {
	                        return employeesIns.size();
	                    }
	                });
		}
	}
	/**
	 * To identify existing(updated projects) and new projects and insert/update it in DB
	 * @param excelesaProjectsList
	 * @param esaProjects
	 */
	private void processEsaProjects(List<EsaProject> excelesaProjectsList, List<EsaProject> esaProjects) {
		Map<Integer, EsaProject> esaProjectsUpdMap = new HashMap<>();
		Map<Integer, EsaProject> esaProjectsInsMap = new HashMap<>();
		
		excelesaProjectsList.forEach((EsaProject esaProject) -> {
			boolean isNewProject = true;
			for (EsaProject dbesaProject : esaProjects) 
			{
				if (dbesaProject.getEsaProjectId() == esaProject.getEsaProjectId()) 
				{
					if(!dbesaProject.equals(esaProject))
					{
						esaProjectsUpdMap.put(esaProject.getEsaProjectId(), esaProject);
					}
					isNewProject = false;
					break;
				}
			}
			if(isNewProject)
			{
				esaProjectsInsMap.put(esaProject.getEsaProjectId(), esaProject);
			}
		}); 
		List<EsaProject> esaProjectsUpd = new ArrayList<>();
		esaProjectsUpd.addAll(esaProjectsUpdMap.values());
		List<EsaProject> esaProjectsIns = new ArrayList<>();
		esaProjectsIns.addAll(esaProjectsInsMap.values());
		//Batch Update for Projects
		if(!esaProjectsUpd.isEmpty())
		{
			this.jdbcTemplate.batchUpdate(
					"UPDATE ESA_PROJECTS SET PROJECT_MANAGER_ID= ? ,PROJECT_MANAGER_NAME= ? ,LEADERSHIP= ?  where ESA_PROJECT_ID= ? ",
	                new BatchPreparedStatementSetter() 
					{
	                    public void setValues(PreparedStatement ps, int i)
							throws SQLException {
	                        ps.setInt(1, esaProjectsUpd.get(i).getProjectManagerId());
	                        ps.setString(2, esaProjectsUpd.get(i).getProjectManagerName());
	                        ps.setString(3, esaProjectsUpd.get(i).getLeadership());
	                        ps.setInt(4, esaProjectsUpd.get(i).getEsaProjectId());
	                    }
	                    public int getBatchSize() {
	                        return esaProjectsUpd.size();
	                    }

	                });
		}
		//Batch Insert for Projects
		if(!esaProjectsIns.isEmpty())
		{
			this.jdbcTemplate.batchUpdate(
					"insert into ESA_PROJECTS(ESA_PROJECT_ID,ESA_CUSTOMER_ID,ESA_CUSTOMER_NAME,INVOICING_COUNTRY,"
							+ "ESA_PROJECT_NAME,PROJECT_MANAGER_ID,PROJECT_MANAGER_NAME,LEADERSHIP) values (?,?,?,?,?,?,?,?)",
	                new BatchPreparedStatementSetter() 
					{
	                    public void setValues(PreparedStatement ps, int i)
							throws SQLException {
	                        ps.setInt(1, esaProjectsIns.get(i).getEsaProjectId());
	                        ps.setInt(2, esaProjectsIns.get(i).getEsaCustomerId());
	                        ps.setString(3, esaProjectsIns.get(i).getEsaCustomerName());
	                        ps.setString(4, esaProjectsIns.get(i).getInvoicingCountry());
	                        ps.setString(5, esaProjectsIns.get(i).getEsaProjectName());
	                        ps.setInt(6, esaProjectsIns.get(i).getProjectManagerId());
	                        ps.setString(7, esaProjectsIns.get(i).getProjectManagerName());
	                        ps.setString(8, esaProjectsIns.get(i).getLeadership());
	                    }
	                    public int getBatchSize() {
	                        return esaProjectsIns.size();
	                    }
	                });
		}
	}

}
