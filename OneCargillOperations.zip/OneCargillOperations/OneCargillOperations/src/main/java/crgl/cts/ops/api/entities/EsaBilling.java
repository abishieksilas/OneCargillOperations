package crgl.cts.ops.api.entities;

public class EsaBilling {
	
	private int billingMasterId;
	private int employeeId;
	private int esaProjectId;
	private int billingHours;
	
	/**
	 * @return the billingMasterId
	 */
	public int getBillingMasterId() {
		return billingMasterId;
	}
	/**
	 * @param billingMasterId the billingMasterId to set
	 */
	public void setBillingMasterId(int billingMasterId) {
		this.billingMasterId = billingMasterId;
	}
	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the esaProjectId
	 */
	public int getEsaProjectId() {
		return esaProjectId;
	}
	/**
	 * @param esaProjectId the esaProjectId to set
	 */
	public void setEsaProjectId(int esaProjectId) {
		this.esaProjectId = esaProjectId;
	}
	/**
	 * @return the esaHours
	 */
	public int getBillingHours() {
		return billingHours;
	}
	/**
	 * @param esaHours the esaHours to set
	 */
	public void setBillingHours(int billingHours) {
		this.billingHours = billingHours;
	}
		
}
