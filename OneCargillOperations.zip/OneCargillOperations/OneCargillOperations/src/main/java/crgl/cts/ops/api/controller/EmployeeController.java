package crgl.cts.ops.api.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import crgl.cts.ops.api.entities.Employee;
import crgl.cts.ops.api.entities.EmployeeProject;
import crgl.cts.ops.api.entities.Employees;
import crgl.cts.ops.api.entities.EsaProject;
import crgl.cts.ops.api.entities.Metadata;
import crgl.cts.ops.api.util.ResponseGateway;
import crgl.cts.ops.service.IEmployeeService;

@RestController
@CrossOrigin(origins="*")
public class EmployeeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeController.class);
	@Autowired
	IEmployeeService iEmployeeUploadService;

	@RequestMapping(value = "employees", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> listOfEmployees() {
		List<Employee> employeeList = iEmployeeUploadService.employeesDisplay();
		Employees employees = new Employees();
		Metadata metadata = new Metadata();
		metadata.setOffset(0);
		metadata.setResultCount(employeeList.size());
		metadata.setTotalCount(employeeList.size());
		employees.setMetadata(metadata);
		employees.setEmployees(employeeList);
		return employeeList;
	}

	@RequestMapping(value = "projects", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EsaProject> listOfEsaProjects() {
		return iEmployeeUploadService.esaProjectsDisplay();
	}

	@RequestMapping(value = "employeeProjects", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EmployeeProject> listOfEmployeeprojects() {
		return iEmployeeUploadService.employeeProjectsDisplay();
	}

	@RequestMapping(value = "employees/upload", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> upload(@RequestParam("file") MultipartFile file) throws Exception {
		LOGGER.info("Invoked Upload employees API");
		List<Employee> employees = new ArrayList<>();
		List<EsaProject> projects = new ArrayList<>();
		List<EmployeeProject> employeeProjects = new ArrayList<>();
		XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
		XSSFSheet worksheet1 = workbook.getSheetAt(0);
		for (int i = 1; i < worksheet1.getPhysicalNumberOfRows(); i++) {
			Employee employee = new Employee();
			EmployeeProject employeeProject = new EmployeeProject();
			EsaProject esaProject = new EsaProject();
			XSSFRow row = worksheet1.getRow(i);
			/**
			 * Get the employee details
			 * 1. Employee ID
			 * 2. Name in CTS
			 * 3. DSID
			 * 4. Name in CArgill
			 * 5. Cargill Email
			 * 6. Onsite/Offshore
			 * 7. Cargill DOJ
			 * 8. Status
			 */
			employee.setEmployeeId((int) row.getCell(0).getNumericCellValue());
			row.getCell(1).setCellType(CellType.STRING);
			employee.setCtsName(row.getCell(1).getStringCellValue());
			row.getCell(2).setCellType(CellType.STRING);
			employee.setDsid(row.getCell(2).getStringCellValue());
			row.getCell(3).setCellType(CellType.STRING);
			employee.setCargillName(row.getCell(3).getStringCellValue());
			row.getCell(4).setCellType(CellType.STRING);
			employee.setCargillEmailId(row.getCell(4).getStringCellValue());
			row.getCell(5).setCellType(CellType.STRING);
			if("onsite".equalsIgnoreCase(row.getCell(5).getStringCellValue()))
			{
				employee.setOnsite(true);
			}
			else
			{
				employee.setOnsite(false);
			}
			if("NUMERIC".equalsIgnoreCase(row.getCell(6).getCellType().name()))
			{
				employee.setCargillDOJ(row.getCell(6).getDateCellValue());
			}
			employee.setActive(true);
			/**
			 * Get the ESA Project details
			 * 1. Project ID
			 * 2. Customer ID
			 * 3. Customer Name
			 * 4. Invoicing Country
			 * 5. Project Name
			 * 6. Project Manager ID
			 * 7. Project Manager Name
			 * 8. Leadership
			 * Get the Employee Project Details
			 * 1. Project ID - Foreign key
			 * 2. Assignment Start date
			 * 3. Assignment end date
			 * 4. Allocation percentage
			 * 5. Project Billability
			 * 6. Work Order Number
			 * 7. SOW Role
			 * 8. Rate -  local
			 * 9. Rate - USD
			 * 10. Work package
			 * 11. Employee ID - Foreign key
			 */
			row.getCell(7).setCellType(CellType.STRING);
			esaProject.setInvoicingCountry(row.getCell(7).getStringCellValue());
			esaProject.setEsaCustomerId((int) row.getCell(8).getNumericCellValue());
			row.getCell(9).setCellType(CellType.STRING);
			esaProject.setEsaCustomerName(row.getCell(9).getStringCellValue());
			esaProject.setEsaProjectId((int) row.getCell(10).getNumericCellValue());
			row.getCell(11).setCellType(CellType.STRING);
			esaProject.setEsaProjectName(row.getCell(11).getStringCellValue());
			esaProject.setProjectManagerId((int) row.getCell(12).getNumericCellValue());
			row.getCell(13).setCellType(CellType.STRING);
			esaProject.setProjectManagerName(row.getCell(13).getStringCellValue());
			if("NUMERIC".equalsIgnoreCase(row.getCell(14).getCellType().name()))
			{
				employeeProject.setAssignmentStartDate(row.getCell(14).getDateCellValue());
			}
			if("NUMERIC".equalsIgnoreCase(row.getCell(15).getCellType().name()))
			{
				employeeProject.setAssignmentEndDate(row.getCell(15).getDateCellValue());
			}
			employeeProject.setAllocationPercentage((int) row.getCell(16).getNumericCellValue());
			row.getCell(17).setCellType(CellType.STRING);
			employeeProject.setProjectBillability(row.getCell(17).getStringCellValue());
			row.getCell(18).setCellType(CellType.STRING);
			employeeProject.setProjectType(row.getCell(18).getStringCellValue());
			row.getCell(19).setCellType(CellType.STRING);
			employeeProject.setWorkOrderNumber(row.getCell(19).getStringCellValue());
			row.getCell(20).setCellType(CellType.STRING);
			employeeProject.setSowRole(row.getCell(20).getStringCellValue());
			if("NUMERIC".equalsIgnoreCase(row.getCell(21).getCellType().name()))
			{
				employeeProject.setRateLocal(BigDecimal.valueOf(row.getCell(21).getNumericCellValue()));
			}
			if("NUMERIC".equalsIgnoreCase(row.getCell(21).getCellType().name()))
			{
				employeeProject.setRateUsd(BigDecimal.valueOf(row.getCell(22).getNumericCellValue()));
			}
			row.getCell(23).setCellType(CellType.STRING);
			employeeProject.setWorkPackage(row.getCell(23).getStringCellValue());
			row.getCell(24).setCellType(CellType.STRING);
			esaProject.setLeadership(row.getCell(24).getStringCellValue());
			//Foreign Keys
			employeeProject.setEsaProjectId(esaProject.getEsaProjectId());
			employeeProject.setEmployeeId(employee.getEmployeeId());
			employees.add(employee);
			employeeProjects.add(employeeProject);
			projects.add(esaProject);
		}
		workbook.close();
		iEmployeeUploadService.upload(employees, projects, employeeProjects);
		ResponseGateway gateway = new ResponseGateway();
		gateway.setUploadresponse("Uploaded Sucessfully");
		ResponseEntity<ResponseGateway> responsegateway = new ResponseEntity<ResponseGateway>(gateway, HttpStatus.OK);
		return responsegateway;
	}
}
