package crgl.cts.ops.service;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import crgl.cts.ops.api.entities.BillingMaster;
import crgl.cts.ops.api.entities.EsaBilling;
import crgl.cts.ops.api.entities.EsaProject;
import crgl.cts.ops.api.entities.ItBilling;

public interface IBillingService {

	void insertBillingAdvice(List<EsaBilling> utilisationReportList, List<EsaBilling> esaBillingList,
			List<ItBilling> itBillingList, Date startDate, Date endDate);

	List<BillingMaster> getBillingDetails(Date startDate, Date endDate);

	ByteArrayInputStream getBillingAdviceExcel(int billingMasterId) throws IOException;

}
