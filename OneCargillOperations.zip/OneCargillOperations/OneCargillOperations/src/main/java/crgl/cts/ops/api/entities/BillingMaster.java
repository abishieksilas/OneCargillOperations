package crgl.cts.ops.api.entities;

import java.util.Date;

public class BillingMaster {

	private int billingMasterId;
	private Date startDate;
	private Date endDate;
	
	
	/**
	 * @return the billingMasterId
	 */
	public int getBillingMasterId() {
		return billingMasterId;
	}
	/**
	 * @param billingMasterId the billingMasterId to set
	 */
	public void setBillingMasterId(int billingMasterId) {
		this.billingMasterId = billingMasterId;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	


}
