package crgl.cts.ops.api.repository;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import crgl.cts.ops.api.entities.BillingAdvice;
import crgl.cts.ops.api.entities.BillingMaster;
import crgl.cts.ops.api.entities.Employee;
import crgl.cts.ops.api.entities.EsaBilling;
import crgl.cts.ops.api.entities.EsaProject;
import crgl.cts.ops.api.entities.ItBilling;

@Repository
public class BillingRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<BillingMaster> getBillingDetails(Date startDate, Date endDate) {
		System.out.println(startDate + "" + endDate);
		List<BillingMaster> billingmasterlist = new ArrayList<BillingMaster>();
		SqlRowSet rowSet = jdbcTemplate
				.queryForRowSet("select * from BILLING_MASTER where START_DATE =? and END_DATE=?", startDate, endDate);
		while (rowSet.next()) {
			BillingMaster billingMaster = new BillingMaster();
			billingMaster.setBillingMasterId(rowSet.getInt("BILLING_MASTER_ID"));
			billingMaster.setStartDate(rowSet.getDate("START_DATE"));
			billingMaster.setEndDate(rowSet.getDate("END_DATE"));
			billingmasterlist.add(billingMaster);
		}
		return billingmasterlist;

	}

	public ByteArrayInputStream getBillingAdviceExcel(int billingMasterId) throws IOException {
		// TODO Auto-generated method stub
		String excelFilePath = "BillingAdvice-export.xlsx";
		List<BillingAdvice> billigadvice = new ArrayList<BillingAdvice>();
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet("select * from BILLING_ADVICE where BILLING_MASTER_ID=?",
				billingMasterId);
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("billingreport");
		writeHeaderLine(sheet);
		writeDataLines(rowSet, workbook, sheet);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		workbook.write(outputStream);

		return new ByteArrayInputStream(outputStream.toByteArray());

	}

	private void writeDataLines(SqlRowSet result, XSSFWorkbook workbook, XSSFSheet sheet) {
		// TODO Auto-generated method stub
		int rowCount = 1;
		while (result.next()) {
			int billingAdviceId = result.getInt("BILLING_ADVICE_ID");

			int masterId = result.getInt("BILLING_MASTER_ID");
			int customerId = result.getInt("CUSTOMER_ID");
			String customerName = result.getString("CUSTOMER_NAME");
			int projectId = result.getInt("PROJECT_ID");
			String ProjectName = result.getString("PROJECT_NAME");
			int projectManagerId = result.getInt("PROJECT_MANAGER_ID");
			String projectManagerName = result.getString("PROJECT_MANAGER_NAME");
			String leadership = result.getString("LEADERSHIP");
			String currencyCode = result.getString("CURRENCY_CODE");
			int employeeId = result.getInt("EMPLOYEE_ID");
			String dsid = result.getString("DSID");
			String employeeName = result.getString("EMPLOYEE_NAME");
			BigDecimal billRateLocalDecimal = result.getBigDecimal("BILL_RATE_LOCAL");// BILL_RATE_LOCAL
																						// DECIMAL(6,2),
			BigDecimal billRateUsdDecimal = result.getBigDecimal("BILL_RATE_USD");// BILL_RATE_USD
																					// DECIMAL(6,2),
			String invoicingCountry = result.getString("INVOICING_COUNTRY");
			int esaHours = result.getInt("ESA_HOURS");
			int clarizenApprovedHours = result.getInt("CLARIZEN_APPROVED_HOURS");
			int pasSubmissionHours = result.getInt("PAS_SUBMISSION_HOURS");
			BigDecimal pasAmount = result.getBigDecimal("PAS_AMOUNT");// PAS_AMOUNT
																		// DECIMAL(6,2),
			int clarizenSubmittedHours = result.getInt("CLARIZEN_SUBMITTED_HOURS");
			BigDecimal submittedAmount = result.getBigDecimal("SUBMITTED_AMOUNT");// SUBMITTED_AMOUNT
																					// DECIMAL(6,2),
			String projectBillability = result.getString("PROJECT_BILLABILITY");
			String invoiceType = result.getString("INVOICE_TYPE");
			String sowRole = result.getString("SOW_ROLE");
			String workOrder = result.getString("WORK_ORDER");
			String workPackage = result.getString("WORK_PACKAGE");
			String remarks = result.getString("REMARKS");

			Row row = sheet.createRow(rowCount++);

			int columnCount = 0;

			Cell cell = row.createCell(columnCount++);
			cell.setCellValue(billingAdviceId);

			cell = row.createCell(columnCount++);
			cell.setCellValue(masterId);

			cell = row.createCell(columnCount++);
			cell.setCellValue(customerId);

			cell = row.createCell(columnCount++);
			cell.setCellValue(customerName);

			cell = row.createCell(columnCount++);
			cell.setCellValue(projectId);

			cell = row.createCell(columnCount++);
			cell.setCellValue(ProjectName);

			cell = row.createCell(columnCount++);
			cell.setCellValue(projectManagerId);

			cell = row.createCell(columnCount++);
			cell.setCellValue(projectManagerName);

			cell = row.createCell(columnCount++);
			cell.setCellValue(leadership);

			cell = row.createCell(columnCount++);
			cell.setCellValue(currencyCode);

			cell = row.createCell(columnCount++);
			cell.setCellValue(employeeId);

			cell = row.createCell(columnCount++);
			cell.setCellValue(dsid);

			cell = row.createCell(columnCount++);
			cell.setCellValue(employeeName);

			
			/*cell = row.createCell(columnCount++); 
			cell.setCellValue(new BigDecimal("billRateLocalDecimal").doubleValue());
			 */
			// cell.setCellValue(billRateLocalDecimal);

			
			/* cell = row.createCell(columnCount++); 
			 cell.setCellValue(new BigDecimal("billRateUsdDecimal").doubleValue());
			 */
			//cell.setCellValue(billRateUsdDecimal);

			cell = row.createCell(columnCount++);
			cell.setCellValue(invoicingCountry);

			cell = row.createCell(columnCount++);
			cell.setCellValue(esaHours);

			cell = row.createCell(columnCount++);
			cell.setCellValue(clarizenApprovedHours);

			cell = row.createCell(columnCount++);
			cell.setCellValue(pasSubmissionHours);

			 Double value = pasAmount.doubleValue();
			    cell.setCellType(CellType.NUMERIC);
			    cell.setCellValue(value);
			/*cell = row.createCell(columnCount++); 
			cell.setCellValue(new BigDecimal("pasAmount").doubleValue());
			*/
			// cell.setCellValue(pasAmount);

			cell = row.createCell(columnCount++);
			cell.setCellValue(clarizenSubmittedHours);

			
			/* cell = row.createCell(columnCount++); 
			 cell.setCellValue(new BigDecimal("submittedAmount").doubleValue());
			 */
			// cell.setCellValue(submittedAmoutn);

			cell = row.createCell(columnCount++);
			cell.setCellValue(projectBillability);

			cell = row.createCell(columnCount++);
			cell.setCellValue(invoiceType);

			cell = row.createCell(columnCount++);
			cell.setCellValue(sowRole);

			cell = row.createCell(columnCount++);
			cell.setCellValue(workOrder);

			cell = row.createCell(columnCount++);
			cell.setCellValue(workPackage);

			cell = row.createCell(columnCount++);
			cell.setCellValue(remarks);

		}
	}

	private void writeHeaderLine(XSSFSheet sheet) {
		// TODO Auto-generated method stub
		Row headerRow = sheet.createRow(0);

		Cell headerCell = headerRow.createCell(0);
		headerCell.setCellValue("CUSTOMER_ID");

		headerCell = headerRow.createCell(1);
		headerCell.setCellValue("CUSTOMER_NAME");

		headerCell = headerRow.createCell(2);
		headerCell.setCellValue("PROJECT_ID");

		headerCell = headerRow.createCell(3);
		headerCell.setCellValue("PROJECT_NAME");

		headerCell = headerRow.createCell(4);
		headerCell.setCellValue("PROJECT_MANAGER_ID");

		headerCell = headerRow.createCell(5);
		headerCell.setCellValue("PROJECT_MANAGER_NAME");

		headerCell = headerRow.createCell(6);
		headerCell.setCellValue("LEADERSHIP");

		headerCell = headerRow.createCell(7);
		headerCell.setCellValue("CURRENCY_CODE");

		headerCell = headerRow.createCell(8);
		headerCell.setCellValue("EMPLOYEE_ID");

		headerCell = headerRow.createCell(9);
		headerCell.setCellValue("DSID");

		headerCell = headerRow.createCell(10);
		headerCell.setCellValue("EMPLOYEE_NAME");

		headerCell = headerRow.createCell(11);
		headerCell.setCellValue("BILL_RATE_LOCAL");

		headerCell = headerRow.createCell(12);
		headerCell.setCellValue("BILL_RATE_USD");

		headerCell = headerRow.createCell(13);
		headerCell.setCellValue("INVOICING_COUNTRY");

		headerCell = headerRow.createCell(14);
		headerCell.setCellValue("ESA_HOURS");

		headerCell = headerRow.createCell(15);
		headerCell.setCellValue("CLARIZEN_APPROVED_HOURS");

		headerCell = headerRow.createCell(16);
		headerCell.setCellValue("PAS_SUBMISSION_HOURS");

		headerCell = headerRow.createCell(17);
		headerCell.setCellValue("PAS_AMOUNT");

		headerCell = headerRow.createCell(18);
		headerCell.setCellValue("CLARIZEN_SUBMITTED_HOURS");

		headerCell = headerRow.createCell(19);
		headerCell.setCellValue("SUBMITTED_AMOUNT");

		headerCell = headerRow.createCell(20);
		headerCell.setCellValue("PROJECT_BILLABILITY");

		headerCell = headerRow.createCell(21);
		headerCell.setCellValue("INVOICE_TYPE");

		headerCell = headerRow.createCell(22);
		headerCell.setCellValue("SOW_ROLE");

		headerCell = headerRow.createCell(23);
		headerCell.setCellValue("WORK_ORDER");

		headerCell = headerRow.createCell(24);
		headerCell.setCellValue("WORK_PACKAGE");

		headerCell = headerRow.createCell(25);
		headerCell.setCellValue("REMARKS");

	}

	public void insertBillingAdvice(List<EsaBilling> utilisationRepostList, List<EsaBilling> esaBillingList,
			List<ItBilling> itBillingList, Date startDate, Date endDate) {
		int billingMasterId = 0;
		jdbcTemplate.update("insert into BILLING_MASTER(START_DATE,END_DATE) values(?,?)", startDate, endDate);
		SqlRowSet rowSet = jdbcTemplate.queryForRowSet(
				"select BILLING_MASTER_ID from BILLING_MASTER where START_DATE=? and END_DATE=?", startDate, endDate);
		while (rowSet.next()) {
			rowSet.getInt("BILLING_MASTER_ID");
		}
		jdbcTemplate.batchUpdate(
				"insert into ESA_BILLING(BILLING_MASTER_ID,EMPLOYEE_ID,ESA_PROJECT,ESA_HOURS) values (?,?,?,?)",
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setInt(1, billingMasterId);
						ps.setInt(2, esaBillingList.get(i).getEmployeeId());
						ps.setInt(3, esaBillingList.get(i).getEsaProjectId());
						ps.setInt(4, esaBillingList.get(i).getBillingHours());
					}

					public int getBatchSize() {
						return esaBillingList.size();
					}
				});
		jdbcTemplate.batchUpdate(
				"insert into IT_BILLING(BILLING_MASTER_ID,DSID,SUBMITTED_HOURS,APPROVED_HOURS) values (?,?,?,?)",
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setInt(1, billingMasterId);
						ps.setString(2, itBillingList.get(i).getDsid());
						ps.setInt(3, itBillingList.get(i).getSubmittedHours());
						ps.setInt(4, itBillingList.get(i).getApprovedHours());
					}

					public int getBatchSize() {
						return esaBillingList.size();
					}
				});
	}

}
