package crgl.cts.ops.api.entities;

public class ItBilling {
	
	private int billingMasterId;
	private String dsid;
	private int submittedHours;
	private int approvedHours;
	
	/**
	 * @return the billingMasterId
	 */
	public int getBillingMasterId() {
		return billingMasterId;
	}
	/**
	 * @param billingMasterId the billingMasterId to set
	 */
	public void setBillingMasterId(int billingMasterId) {
		this.billingMasterId = billingMasterId;
	}
	/**
	 * @return the dsid
	 */
	public String getDsid() {
		return dsid;
	}
	/**
	 * @param string the dsid to set
	 */
	public void setDsid(String string) {
		this.dsid = string;
	}
	/**
	 * @return the submittedHours
	 */
	public int getSubmittedHours() {
		return submittedHours;
	}
	/**
	 * @param submittedHours the submittedHours to set
	 */
	public void setSubmittedHours(int submittedHours) {
		this.submittedHours = submittedHours;
	}
	/**
	 * @return the approvedHours
	 */
	public int getApprovedHours() {
		return approvedHours;
	}
	/**
	 * @param approvedHours the approvedHours to set
	 */
	public void setApprovedHours(int approvedHours) {
		this.approvedHours = approvedHours;
	}
	
}
