package crgl.cts.ops.api.entities;

import java.math.BigDecimal;

public class BillingAdvice {
	private int billingMasterId;
	private int customerId;
	private String customerName;
	private int projectId;
	private String ProjectName;
	private int projectManagerId;
	private String projectManagerName;
	private String leadership;
	private String currencyCode;
	private int employeeId;
	private String dsid;
	private String employeeName;
	private BigDecimal billRateLocalDecimal;//BILL_RATE_LOCAL DECIMAL(6,2),
	private BigDecimal billRateUsdDecimal;//BILL_RATE_USD DECIMAL(6,2),
	private String invoicingCountry;
	private int esaHours;
	private int clarizenApprovedHours;
	private int pasSubmissionHours;
	private BigDecimal pasAmount;//PAS_AMOUNT DECIMAL(6,2),
	private int clarizenSubmittedHours;
	private BigDecimal submittedAmoutn;//SUBMITTED_AMOUNT DECIMAL(6,2),
	private String projectBillability;
	private String invoiceType;
	private String sowRole;
	private String workOrder;
	private String workPackage;
	private String remarks;
	/**
	 * @return the billingMasterId
	 */
	public int getBillingMasterId() {
		return billingMasterId;
	}
	/**
	 * @param billingMasterId the billingMasterId to set
	 */
	public void setBillingMasterId(int billingMasterId) {
		this.billingMasterId = billingMasterId;
	}
	/**
	 * @return the customerId
	 */
	public int getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the projectId
	 */
	public int getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return ProjectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}
	/**
	 * @return the projectManagerId
	 */
	public int getProjectManagerId() {
		return projectManagerId;
	}
	/**
	 * @param projectManagerId the projectManagerId to set
	 */
	public void setProjectManagerId(int projectManagerId) {
		this.projectManagerId = projectManagerId;
	}
	/**
	 * @return the projectManagerName
	 */
	public String getProjectManagerName() {
		return projectManagerName;
	}
	/**
	 * @param projectManagerName the projectManagerName to set
	 */
	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}
	/**
	 * @return the leadership
	 */
	public String getLeadership() {
		return leadership;
	}
	/**
	 * @param leadership the leadership to set
	 */
	public void setLeadership(String leadership) {
		this.leadership = leadership;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the dsid
	 */
	public String getDsid() {
		return dsid;
	}
	/**
	 * @param dsid the dsid to set
	 */
	public void setDsid(String dsid) {
		this.dsid = dsid;
	}
	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}
	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	/**
	 * @return the billRateLocalDecimal
	 */
	public BigDecimal getBillRateLocalDecimal() {
		return billRateLocalDecimal;
	}
	/**
	 * @param billRateLocalDecimal the billRateLocalDecimal to set
	 */
	public void setBillRateLocalDecimal(BigDecimal billRateLocalDecimal) {
		this.billRateLocalDecimal = billRateLocalDecimal;
	}
	/**
	 * @return the billRateUsdDecimal
	 */
	public BigDecimal getBillRateUsdDecimal() {
		return billRateUsdDecimal;
	}
	/**
	 * @param billRateUsdDecimal the billRateUsdDecimal to set
	 */
	public void setBillRateUsdDecimal(BigDecimal billRateUsdDecimal) {
		this.billRateUsdDecimal = billRateUsdDecimal;
	}
	/**
	 * @return the invoicingCountry
	 */
	public String getInvoicingCountry() {
		return invoicingCountry;
	}
	/**
	 * @param invoicingCountry the invoicingCountry to set
	 */
	public void setInvoicingCountry(String invoicingCountry) {
		this.invoicingCountry = invoicingCountry;
	}
	/**
	 * @return the esaHours
	 */
	public int getEsaHours() {
		return esaHours;
	}
	/**
	 * @param esaHours the esaHours to set
	 */
	public void setEsaHours(int esaHours) {
		this.esaHours = esaHours;
	}
	/**
	 * @return the clarizenApprovedHours
	 */
	public int getClarizenApprovedHours() {
		return clarizenApprovedHours;
	}
	/**
	 * @param clarizenApprovedHours the clarizenApprovedHours to set
	 */
	public void setClarizenApprovedHours(int clarizenApprovedHours) {
		this.clarizenApprovedHours = clarizenApprovedHours;
	}
	/**
	 * @return the pasSubmissionHours
	 */
	public int getPasSubmissionHours() {
		return pasSubmissionHours;
	}
	/**
	 * @param pasSubmissionHours the pasSubmissionHours to set
	 */
	public void setPasSubmissionHours(int pasSubmissionHours) {
		this.pasSubmissionHours = pasSubmissionHours;
	}
	/**
	 * @return the pasAmount
	 */
	public BigDecimal getPasAmount() {
		return pasAmount;
	}
	/**
	 * @param pasAmount the pasAmount to set
	 */
	public void setPasAmount(BigDecimal pasAmount) {
		this.pasAmount = pasAmount;
	}
	/**
	 * @return the clarizenSubmittedHours
	 */
	public int getClarizenSubmittedHours() {
		return clarizenSubmittedHours;
	}
	/**
	 * @param clarizenSubmittedHours the clarizenSubmittedHours to set
	 */
	public void setClarizenSubmittedHours(int clarizenSubmittedHours) {
		this.clarizenSubmittedHours = clarizenSubmittedHours;
	}
	/**
	 * @return the submittedAmoutn
	 */
	public BigDecimal getSubmittedAmoutn() {
		return submittedAmoutn;
	}
	/**
	 * @param submittedAmoutn the submittedAmoutn to set
	 */
	public void setSubmittedAmoutn(BigDecimal submittedAmoutn) {
		this.submittedAmoutn = submittedAmoutn;
	}
	/**
	 * @return the projectBillability
	 */
	public String getProjectBillability() {
		return projectBillability;
	}
	/**
	 * @param projectBillability the projectBillability to set
	 */
	public void setProjectBillability(String projectBillability) {
		this.projectBillability = projectBillability;
	}
	/**
	 * @return the invoiceType
	 */
	public String getInvoiceType() {
		return invoiceType;
	}
	/**
	 * @param invoiceType the invoiceType to set
	 */
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	/**
	 * @return the sowRole
	 */
	public String getSowRole() {
		return sowRole;
	}
	/**
	 * @param sowRole the sowRole to set
	 */
	public void setSowRole(String sowRole) {
		this.sowRole = sowRole;
	}
	/**
	 * @return the workOrder
	 */
	public String getWorkOrder() {
		return workOrder;
	}
	/**
	 * @param workOrder the workOrder to set
	 */
	public void setWorkOrder(String workOrder) {
		this.workOrder = workOrder;
	}
	/**
	 * @return the workPackage
	 */
	public String getWorkPackage() {
		return workPackage;
	}
	/**
	 * @param workPackage the workPackage to set
	 */
	public void setWorkPackage(String workPackage) {
		this.workPackage = workPackage;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
