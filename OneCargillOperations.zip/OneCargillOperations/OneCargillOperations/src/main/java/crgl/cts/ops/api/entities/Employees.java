package crgl.cts.ops.api.entities;

import java.util.List;

public class Employees {
	private Metadata metadata;
	private List<Employee> employees;
	public Metadata getMetadata() {
		return metadata;
	}
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
}
