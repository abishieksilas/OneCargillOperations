package crgl.cts.ops.api.util;


public class ResponseGateway {
	private String uploadresponse;

	/**
	 * @return the uploadresponse
	 */
	public String getUploadresponse() {
		return uploadresponse;
	}

	/**
	 * @param uploadresponse the uploadresponse to set
	 */
	public void setUploadresponse(String uploadresponse) {
		this.uploadresponse = uploadresponse;
	}
	

}
