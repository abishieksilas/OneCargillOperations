package crgl.cts.ops.api.entities;

import java.util.Date;

public class Employee {
	private int employeeId;
	private String ctsName;
	private String dsid;
	private String cargillName;
	private String cargillEmailId;
    private boolean isOnsite;
	private Date cargillDOJ;
	private boolean isActive;
	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the ctsName
	 */
	public String getCtsName() {
		return ctsName;
	}
	/**
	 * @param ctsName the ctsName to set
	 */
	public void setCtsName(String ctsName) {
		this.ctsName = ctsName;
	}
	/**
	 * @return the dsid
	 */
	public String getDsid() {
		return dsid;
	}
	/**
	 * @param dsid the dsid to set
	 */
	public void setDsid(String dsid) {
		this.dsid = dsid;
	}
	/**
	 * @return the cargillName
	 */
	public String getCargillName() {
		return cargillName;
	}
	/**
	 * @param cargillName the cargillName to set
	 */
	public void setCargillName(String cargillName) {
		this.cargillName = cargillName;
	}
	/**
	 * @return the cargillEmailId
	 */
	public String getCargillEmailId() {
		return cargillEmailId;
	}
	/**
	 * @param cargillEmailId the cargillEmailId to set
	 */
	public void setCargillEmailId(String cargillEmailId) {
		this.cargillEmailId = cargillEmailId;
	}
	/**
	 * @return the isOnsite
	 */
	public boolean isOnsite() {
		return isOnsite;
	}
	/**
	 * @param isOnsite the isOnsite to set
	 */
	public void setOnsite(boolean isOnsite) {
		this.isOnsite = isOnsite;
	}
	/**
	 * @return the cargillDOJ
	 */
	public Date getCargillDOJ() {
		return cargillDOJ;
	}
	/**
	 * @param cargillDOJ the cargillDOJ to set
	 */
	public void setCargillDOJ(Date cargillDOJ) {
		this.cargillDOJ = cargillDOJ;
	}
	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	/**
	 * To implement equals functionality
	 */
     public boolean equals(Employee employee) {
        return this.employeeId == employee.getEmployeeId() &&
        		this.dsid.equalsIgnoreCase(employee.getDsid()) &&
        		this.cargillName.equalsIgnoreCase(employee.getCargillName()) &&
        		this.cargillDOJ != null && employee.getCargillDOJ() != null &&
        		this.cargillDOJ.compareTo(employee.getCargillDOJ()) == 0 &&
        		this.cargillEmailId.equalsIgnoreCase(employee.getCargillEmailId()) &&
        		this.isOnsite == employee.isOnsite() &&
        		this.isActive == employee.isActive();
     }
	
}
