package crgl.cts.ops.service;

import java.util.List;

import crgl.cts.ops.api.entities.Employee;
import crgl.cts.ops.api.entities.EmployeeProject;
import crgl.cts.ops.api.entities.EsaProject;

public interface IEmployeeService {

	void upload(List<Employee> employees, List<EsaProject> projects, List<EmployeeProject> employeeProjects);

	List<Employee> employeesDisplay();

	List<EsaProject> esaProjectsDisplay();

	List<EmployeeProject> employeeProjectsDisplay();

}
