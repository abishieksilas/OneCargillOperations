package crgl.cts.ops.api.service.impl;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crgl.cts.ops.api.entities.BillingMaster;
import crgl.cts.ops.api.entities.EsaBilling;
import crgl.cts.ops.api.entities.EsaProject;
import crgl.cts.ops.api.entities.ItBilling;
import crgl.cts.ops.api.repository.BillingRepository;
import crgl.cts.ops.service.IBillingService;
@Service
public class BillingServiceImpl implements IBillingService {
	@Autowired
	BillingRepository billingRepository;
	
	@Override
	public List<BillingMaster> getBillingDetails(Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		return billingRepository.getBillingDetails(startDate,endDate);
	}

	@Override
	public void insertBillingAdvice(List<EsaBilling> utilisationReportList, List<EsaBilling> esaBillingList,
			List<ItBilling> itBillingList, Date startDate, Date endDate) {
		billingRepository.insertBillingAdvice(utilisationReportList, esaBillingList, itBillingList, startDate, endDate);
	}

	@Override
	public ByteArrayInputStream getBillingAdviceExcel(int billingMasterId) throws IOException {
		// TODO Auto-generated method stub
		return billingRepository.getBillingAdviceExcel(billingMasterId);
	}	

}
