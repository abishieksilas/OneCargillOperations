package crgl.cts.ops.api.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crgl.cts.ops.api.entities.Employee;
import crgl.cts.ops.api.entities.EmployeeProject;
import crgl.cts.ops.api.entities.EsaProject;
import crgl.cts.ops.api.repository.EmployeeRepository;
import crgl.cts.ops.service.IEmployeeService;
@Service
public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	EmployeeRepository employeeUploadRepository;

	public void upload(List<Employee> employees, List<EsaProject> esaProjects, List<EmployeeProject> employeeProjects) {
		employeeUploadRepository.upload(employees, esaProjects, employeeProjects);
	}

	public List<Employee> employeesDisplay() {
		return employeeUploadRepository.getEmployees();
	}

	public List<EsaProject> esaProjectsDisplay() {
		return employeeUploadRepository.getProjects();
	}

	public List<EmployeeProject> employeeProjectsDisplay() {
		return employeeUploadRepository.getEmployeeProjects();
	}
}
