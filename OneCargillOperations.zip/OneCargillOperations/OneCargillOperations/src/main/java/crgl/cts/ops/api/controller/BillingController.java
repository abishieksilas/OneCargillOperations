package crgl.cts.ops.api.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import crgl.cts.ops.api.entities.BillingMaster;
import crgl.cts.ops.api.entities.EsaBilling;
import crgl.cts.ops.api.entities.ItBilling;
import crgl.cts.ops.api.util.ResponseGateway;
import crgl.cts.ops.service.IBillingService;

@RestController
@CrossOrigin(origins = "*")
public class BillingController {
	@Autowired
	IBillingService billingService;

	@RequestMapping(value = "billing/searchbydate", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<BillingMaster> billingMasterReport(
			@RequestParam("startdate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("enddate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
		return billingService.getBillingDetails(startDate, endDate);
	}

	@RequestMapping(value = "billingadvice/download", method = RequestMethod.GET, produces = "application/octet-stream")
	public ResponseEntity<InputStreamResource> billingAdviceReport(@RequestParam("billingMasterId") int billingMasterId,
			HttpServletResponse response) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=BillingAdvice-export.xlsx");
		System.out.println("before return in controller");
		ByteArrayInputStream in = billingService.getBillingAdviceExcel(billingMasterId);
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(BillingController.class);

	@RequestMapping(value = "billing/upload", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseGateway> insertBillingAdvice(
			@RequestParam("utilizationReport") MultipartFile utilizationReport,
			@RequestParam("esaTimesheetReport") MultipartFile esaReport,
			@RequestParam("itBillingReport") MultipartFile itBillingReport,
			@RequestParam("startdate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@RequestParam("enddate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) throws Exception {
		LOGGER.info("Invoked Upload billing API");
		List<EsaBilling> utilisationReportList = new ArrayList<>();
		List<EsaBilling> esaBillingList = new ArrayList<>();
		List<ItBilling> itBillingList = new ArrayList<>();
		XSSFWorkbook utilizationExcel = new XSSFWorkbook(utilizationReport.getInputStream());
		XSSFWorkbook esaExcel = new XSSFWorkbook(esaReport.getInputStream());
		XSSFWorkbook itBillingExcel = new XSSFWorkbook(itBillingReport.getInputStream());
		XSSFSheet utilizationSheet = utilizationExcel.getSheetAt(0);
		XSSFSheet esaSheet = esaExcel.getSheetAt(0);
		List<Integer> excludedCustomers = new ArrayList<>();
		excludedCustomers.add(1233208);
		excludedCustomers.add(1228394);
		excludedCustomers.add(1233209);
		for (int i = 1; i < utilizationSheet.getPhysicalNumberOfRows(); i++) {
			EsaBilling esaBilling = new EsaBilling();
			XSSFRow row = utilizationSheet.getRow(i);
			row.getCell(13).setCellType(CellType.STRING);
			// Get only the project type = BTM and avoid excluded project list
			if ("BTM".equalsIgnoreCase(row.getCell(13).getStringCellValue())
					&& !excludedCustomers.contains((int) row.getCell(15).getNumericCellValue())) {
				esaBilling.setEmployeeId((int) row.getCell(1).getNumericCellValue());
				esaBilling.setEsaProjectId((int) row.getCell(6).getNumericCellValue());
				utilisationReportList.add(esaBilling);
			}
		}
		for (int i = 1; i < esaSheet.getPhysicalNumberOfRows(); i++) {
			EsaBilling esaBilling = new EsaBilling();
			XSSFRow row = esaSheet.getRow(i);
			esaBilling.setEmployeeId((int) row.getCell(1).getNumericCellValue());
			esaBilling.setEsaProjectId((int) row.getCell(6).getNumericCellValue());
			esaBilling.setBillingHours((int) row.getCell(11).getNumericCellValue());
			esaBillingList.add(esaBilling);
		}

		for (int count = 0; count < itBillingExcel.getNumberOfSheets(); count++) {
			XSSFSheet itBillingSheet = itBillingExcel.getSheetAt(count);
			for (int i = 1; i < itBillingSheet.getPhysicalNumberOfRows(); i++) {
				ItBilling itbilling = new ItBilling();
				XSSFRow row = itBillingSheet.getRow(i);
				row.getCell(2).setCellType(CellType.STRING);
				itbilling.setDsid(row.getCell(17).getStringCellValue());
				itbilling.setSubmittedHours((int) row.getCell(20).getNumericCellValue());
				itbilling.setApprovedHours((int) row.getCell(10).getNumericCellValue());
				itBillingList.add(itbilling);
			}
		}
		billingService.insertBillingAdvice(utilisationReportList, esaBillingList, itBillingList, startDate, endDate);
		return null;

	}
}
