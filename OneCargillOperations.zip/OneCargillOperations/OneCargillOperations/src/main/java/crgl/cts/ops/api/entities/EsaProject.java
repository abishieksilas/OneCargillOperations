package crgl.cts.ops.api.entities;

public class EsaProject {

	private int esaProjectId;
	private int esaCustomerId;
	private String esaCustomerName;
	private String invoicingCountry;
	private String esaProjectName;
	private int projectManagerId;
	private String projectManagerName;
	private String leadership;
	/**
	 * @return the esaProjectId
	 */
	public int getEsaProjectId() {
		return esaProjectId;
	}
	/**
	 * @param esaProjectId the esaProjectId to set
	 */
	public void setEsaProjectId(int esaProjectId) {
		this.esaProjectId = esaProjectId;
	}
	/**
	 * @return the esaCustomerId
	 */
	public int getEsaCustomerId() {
		return esaCustomerId;
	}
	/**
	 * @param esaCustomerId the esaCustomerId to set
	 */
	public void setEsaCustomerId(int esaCustomerId) {
		this.esaCustomerId = esaCustomerId;
	}
	/**
	 * @return the esaCustomerName
	 */
	public String getEsaCustomerName() {
		return esaCustomerName;
	}
	/**
	 * @param esaCustomerName the esaCustomerName to set
	 */
	public void setEsaCustomerName(String esaCustomerName) {
		this.esaCustomerName = esaCustomerName;
	}
	/**
	 * @return the invoicingCountry
	 */
	public String getInvoicingCountry() {
		return invoicingCountry;
	}
	/**
	 * @param invoicingCountry the invoicingCountry to set
	 */
	public void setInvoicingCountry(String invoicingCountry) {
		this.invoicingCountry = invoicingCountry;
	}
	/**
	 * @return the esaProjectName
	 */
	public String getEsaProjectName() {
		return esaProjectName;
	}
	/**
	 * @param esaProjectName the esaProjectName to set
	 */
	public void setEsaProjectName(String esaProjectName) {
		this.esaProjectName = esaProjectName;
	}
	/**
	 * @return the projectManagerId
	 */
	public int getProjectManagerId() {
		return projectManagerId;
	}
	/**
	 * @param projectManagerId the projectManagerId to set
	 */
	public void setProjectManagerId(int projectManagerId) {
		this.projectManagerId = projectManagerId;
	}
	/**
	 * @return the projectManagerName
	 */
	public String getProjectManagerName() {
		return projectManagerName;
	}
	/**
	 * @param projectManagerName the projectManagerName to set
	 */
	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}
	/**
	 * @return the leadership
	 */
	public String getLeadership() {
		return leadership;
	}
	/**
	 * @param leadership the leadership to set
	 */
	public void setLeadership(String leadership) {
		this.leadership = leadership;
	}
	/**
	 * To implement equals functionality
	 */
     public boolean equals(EsaProject project) {
        return this.esaProjectId == project.getEsaProjectId() &&
        		this.projectManagerId == project.getProjectManagerId() &&
        		this.projectManagerName.equalsIgnoreCase(project.getProjectManagerName()) &&
        		this.leadership.equalsIgnoreCase(project.getLeadership());
     }
	
}
