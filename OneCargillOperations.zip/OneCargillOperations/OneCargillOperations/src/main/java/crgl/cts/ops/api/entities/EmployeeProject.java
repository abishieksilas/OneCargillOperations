package crgl.cts.ops.api.entities;

import java.math.BigDecimal;
import java.util.Date;

public class EmployeeProject {

	private int empProjId;
	private int employeeId;
	private int esaProjectId;
	private Date assignmentStartDate;
	private Date assignmentEndDate;
	private int allocationPercentage;
	private String projectBillability;
	private String projectType;
	private String workOrderNumber;
	private String sowRole;
	private BigDecimal rateLocal;
	private BigDecimal rateUsd;
	private String workPackage;
	/**
	 * @return the empProjId
	 */
	public int getEmpProjId() {
		return empProjId;
	}
	/**
	 * @param empProjId the empProjId to set
	 */
	public void setEmpProjId(int empProjId) {
		this.empProjId = empProjId;
	}
	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the esaProjectId
	 */
	public int getEsaProjectId() {
		return esaProjectId;
	}
	/**
	 * @param esaProjectId the esaProjectId to set
	 */
	public void setEsaProjectId(int esaProjectId) {
		this.esaProjectId = esaProjectId;
	}
	/**
	 * @return the assignmentStartDate
	 */
	public Date getAssignmentStartDate() {
		return assignmentStartDate;
	}
	/**
	 * @param assignmentStartDate the assignmentStartDate to set
	 */
	public void setAssignmentStartDate(Date assignmentStartDate) {
		this.assignmentStartDate = assignmentStartDate;
	}
	/**
	 * @return the assignmentEndDate
	 */
	public Date getAssignmentEndDate() {
		return assignmentEndDate;
	}
	/**
	 * @param assignmentEndDate the assignmentEndDate to set
	 */
	public void setAssignmentEndDate(Date assignmentEndDate) {
		this.assignmentEndDate = assignmentEndDate;
	}
	/**
	 * @return the allocationPercentage
	 */
	public int getAllocationPercentage() {
		return allocationPercentage;
	}
	/**
	 * @param allocationPercentage the allocationPercentage to set
	 */
	public void setAllocationPercentage(int allocationPercentage) {
		this.allocationPercentage = allocationPercentage;
	}
	/**
	 * @return the projectBillability
	 */
	public String getProjectBillability() {
		return projectBillability;
	}
	/**
	 * @param projectBillability the projectBillability to set
	 */
	public void setProjectBillability(String projectBillability) {
		this.projectBillability = projectBillability;
	}
	/**
	 * @return the projectType
	 */
	public String getProjectType() {
		return projectType;
	}
	/**
	 * @param projectType the projectType to set
	 */
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	/**
	 * @return the workOrderNumber
	 */
	public String getWorkOrderNumber() {
		return workOrderNumber;
	}
	/**
	 * @param workOrderNumber the workOrderNumber to set
	 */
	public void setWorkOrderNumber(String workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}
	/**
	 * @return the sowRole
	 */
	public String getSowRole() {
		return sowRole;
	}
	/**
	 * @param sowRole the sowRole to set
	 */
	public void setSowRole(String sowRole) {
		this.sowRole = sowRole;
	}
	/**
	 * @return the rateLocal
	 */
	public BigDecimal getRateLocal() {
		return rateLocal;
	}
	/**
	 * @param rateLocal the rateLocal to set
	 */
	public void setRateLocal(BigDecimal rateLocal) {
		this.rateLocal = rateLocal;
	}
	/**
	 * @return the rateUsd
	 */
	public BigDecimal getRateUsd() {
		return rateUsd;
	}
	/**
	 * @param rateUsd the rateUsd to set
	 */
	public void setRateUsd(BigDecimal rateUsd) {
		this.rateUsd = rateUsd;
	}
	/**
	 * @return the workPackage
	 */
	public String getWorkPackage() {
		return workPackage;
	}
	/**
	 * @param workPackage the workPackage to set
	 */
	public void setWorkPackage(String workPackage) {
		this.workPackage = workPackage;
	}
	
	
	
	
}
